let pergunta1 = 0
let pergunta2 = 0
let pergunta3 = 0
let pergunta4 = 0
let pergunta5 = 0
let pergunta6 = 0
let vida = 3
var final

let alert1 = Number(alert("HISTÓRIA DE MUNA DAHOUK\nPRESTE MUITA ATENÇÃO!\n\n\nMuna Dahouk é uma refugiada síria que fugiu da guerra civil em seu país. Após chegar à Alemanha, ela se dedicou a ajudar outros refugiados, fundando uma ONG focada em reassentamento e integração cultural. Seu trabalho inclui apoiar a adaptação dos novos imigrantes e facilitar sua integração na sociedade alemã.\n\n Esse resumo deve ajudar a escolher as respostas corretas nas perguntas sobre Muna Dahouk\n\nREGRAS:\n\nVocê começa com 3 vidas\n.Para cada pergunta correta, você avança em sua jornada\n.Respostas erradas fazem você perder uma vida\n.O objetivo é chegar às Olimpíadas com o máximo de vidas possível.."))








//PERGUNTA 1
while(pergunta1 != 2){
while(vida == 0){
        alert("Suas vidas acabaram, Tente novamente!")
}
    
    pergunta1 = Number(prompt("Pergunta 1:\nAntes de buscar refúgio na Alemanha, de qual país Muna Dahouk fugiu devido ao conflito armado\n1- Egito\n2- Síria\n3- Líbano")) 


if(pergunta1 == 1){
    vida -= 1
        alert("Resposta errada, tente novamente\nsua vida caiu de 3 para " +vida+ " tome mais cuidado da próxima vez!")
}





if(pergunta1 == 3){
    vida -= 1
        alert("Resposta errada, tente novamente\nsua vida caiu de 3 para " +vida+ " tome mais cuidado da próxima vez!")
}





if(pergunta1 == 2){
    vida += 1
        alert("Resposta correta! Sua vida agora está em " +vida+ " continue assim!")
}
}







//PERGUNTA 2
while(pergunta2 != 2){
while(vida == 0){
        alert("Suas vidas acabaram, Tente novamente!")
    }

    pergunta2 = Number(prompt("Pergunta 2: \nEm que país Muna Dahouk se estabeleceu após fugir de seu país natal?\n1- França\n2- Alemanha\n3- Suécia"))


if(pergunta2 == 1){
    vida -= 1
        alert("Resposta errada, tente novamente\nsua vida caiu de 3 para " +vida+ " tome mais cuidado da próxima vez!")
}




if(pergunta2 == 3){
    vida -= 1
        alert("Resposta errada, tente novamente\nsua vida caiu de 3 para " +vida+ " tome mais cuidado da próxima vez!")
}




if(pergunta2 == 2){
    vida += 1
        alert("Resposta correta! Sua vida agora está em " +vida+ " continue assim!")
}
}






//PERGUNTA 3
while(pergunta3 != 3){
while(vida == 0){
            alert("Suas vidas acabaram, Tente novamente!")
    }
    
    pergunta3 = Number(prompt("Pergunta 3: \nQual foi o motivo que levou Muna Dahouk a fugir de seu país?\n1- Crise Econômica\n2- Perseguição Política\n3- Guerra Cívil"))
    
    if(pergunta3 == 1){
        vida -= 1
            alert("Resposta errada, tente novamente\nsua vida caiu de 3 para " +vida+ " tome mais cuidado da próxima vez!")
    }
    
    if(pergunta3 == 2){
        vida -= 1
            alert("Resposta errada, tente novamente\nsua vida caiu de 3 para " +vida+ " tome mais cuidado da próxima vez!")
    }

}
    if(pergunta3 == 3){
        vida += 1
            alert("Resposta correta! Sua vida agora está em " +vida+ " continue assim!")
    }





//PERGUNTA 4
while(pergunta4 != 3){
while(vida == 0){
            alert("Suas vidas acabaram, Tente novamente!")
    }
    
pergunta4 = Number(prompt("Pergunta 4: \nO que Muna Dahouk fez após chegar à Alemanha?\n1- Trabalho em uma grande corporaçãoa\n2- Estudou em uma universidade Alemã\n3- Fundou uma ONG focada em reassentamento e integração cultural de refugiados"))
    
    if(pergunta4 == 1){
        vida -= 1
            alert("Resposta errada, tente novamente\nsua vida caiu de 3 para " +vida+ " tome mais cuidado da próxima vez!")
    }
    
    if(pergunta4 == 2){
        vida -= 1
            alert("Resposta errada, tente novamente\nsua vida caiu de 3 para " +vida+ " tome mais cuidado da próxima vez!")
    }

}
    if(pergunta4 == 3){
        vida += 1
            alert("Resposta correta! Sua vida agora está em " +vida+ " continue assim!")
    }






//conquista    

var ourin = Number(prompt("Parabéns!!\n\nVocê está quase chegando nas olimpíadas mas ve uma pessoa pedindo ajuda, o que você quer fazer?\n1- Ajudar\n2- Seguir em frente para o caminho das olimpíadas"))

if(ourin == 1){

alert("Parabéns, você conquistou \n\nHUMILDADE")
}
if(ourin == 2){

    alert("Ok, vamos prosseguir")









//PERGUNTA 5
while(pergunta5 != 2){
    while(vida == 0){
            alert("Suas vidas acabaram, Tente novamente!")
    }
    
    pergunta5 = Number(prompt("Após chegar à Alemanha, qual foi a principal área de foco para Muna Dahouk?\n\n1- Negócios e comércio\n2- Ajuda a refugiados\n3- Turismo e hospitalidade"))
    
        if(pergunta5 == 1){
            vida -= 1
                alert("Resposta errada, tente novamente\nsua vida caiu de 3 para " +vida+ " tome mais cuidado da próxima vez!")
        }
    
    
        if(pergunta5 == 3){
            vida -= 1
                alert("Resposta errada, tente novamente\nsua vida caiu de 3 para " +vida+ " tome mais cuidado da próxima vez!")
        }
    
    }
        
    
    
        if(pergunta5 == 2){
    
            vida += 1
                alert("Resposta correta! Sua vida agora está em " +vida+ " continue assim!")
    
        }
    
    while(pergunta6 != 1){
    while(vida == 0){
        alert("Suas vidas acabaram, Tente novamente!")
    }
    
    //PERGUNTA 6
    pergunta6 = Number(prompt("Qual é a principal missão da ONG fundada por Muna Dahouk?\n\n1- Reassentar e integrar refugiados\n2- Apoiar empresas locais\n3- Promover eventos esportivos"))
    
    
        if(pergunta6 == 2){
    
        vida -= 1
            alert("Resposta errada, tente novamente\nsua vida caiu de 3 para " +vida+ " tome mais cuidado da próxima vez!")
    
    
        if(pergunta6 == 3){
    
        vida -= 1
            alert("Resposta errada, tente novamente\nsua vida caiu de 3 para " +vida+ " tome mais cuidado da próxima vez!")
    
    }
}
    
        if(pergunta6 == 1){
    
        vida += 1
            alert("Resposta correta! Sua vida agora está em " +vida+ " continue assim!")
        
        
if(ourin == 2){
            alert("Parabéns você chegou nas olimpíadas, como você decidiu não ajudar a pessoa, você chegou em terceiro lugar!!!\n\ntente novamente para chegar em primeiro!")


}
        }
    }









}
var ourin2 = Number(prompt("A pessoa te pede para comprar uma comida pois está com muita fome, o que deseja fazer?\n\n1- Ajudar comprando comida\n2- Ignorar e prosseguir para as olimpíadas"))

if(ourin2 == 1){

alert("Parabéns, você conquistou \n\nGENTILEZA")
}

if(ourin2 == 2){

    alert("Ok, vamos prosseguir")


//PERGUNTA 5
while(pergunta5 != 2){
    while(vida == 0){
            alert("Suas vidas acabaram, Tente novamente!")
    }
    
    pergunta5 = Number(prompt("Após chegar à Alemanha, qual foi a principal área de foco para Muna Dahouk?\n\n1- Negócios e comércio\n2- Ajuda a refugiados\n3- Turismo e hospitalidade"))
    
        if(pergunta5 == 1){
            vida -= 1
                alert("Resposta errada, tente novamente\nsua vida caiu de 3 para " +vida+ " tome mais cuidado da próxima vez!")
        }
    
    
        if(pergunta5 == 3){
            vida -= 1
                alert("Resposta errada, tente novamente\nsua vida caiu de 3 para " +vida+ " tome mais cuidado da próxima vez!")
        }
    
    }
        
    
    
        if(pergunta5 == 2){
    
            vida += 1
                alert("Resposta correta! Sua vida agora está em " +vida+ " continue assim!")
    
        }
    
    while(pergunta6 != 1){
    while(vida == 0){
        alert("Suas vidas acabaram, Tente novamente!")
    }
    
    //PERGUNTA 6
    pergunta6 = Number(prompt("Qual é a principal missão da ONG fundada por Muna Dahouk?\n\n1- Reassentar e integrar refugiados\n2- Apoiar empresas locais\n3- Promover eventos esportivos"))
    
    
        if(pergunta6 == 2){
    
        vida -= 1
            alert("Resposta errada, tente novamente\nsua vida caiu de 3 para " +vida+ " tome mais cuidado da próxima vez!")
    
    
        if(pergunta6 == 3){
    
        vida -= 1
            alert("Resposta errada, tente novamente\nsua vida caiu de 3 para " +vida+ " tome mais cuidado da próxima vez!")
    
    }
}
    
        if(pergunta6 == 1){
    
        vida += 1
            alert("Resposta correta! Sua vida agora está em " +vida+ " continue assim!")
        
        
            alert("Parabéns você chegou nas olimpíadas, como você decidiu não ajudar a pessoa, você chegou em terceiro lugar!!!\n\ntente novamente para chegar em primeiro!")


        }
    }

    
}
var ourin3 = Number(prompt("Vocês estão andando por paris e encontram uma padaria querem ir lá?\n1- Sim\n2- Não"))

if(ourin3 == 1){

var ourin4 = Number(prompt("Vocês chegaram na padaria o que quer comprar para a pessoa comer?\n\n1- Pastel de Carne R$8,00\n2- Bolo de Chocolate R$14,00\n3- Sonho R$9,00\n4- Sanduíche R$6,00"))
}
if(ourin3 == 2){

        alert("Ok, vamos prosseguir")
    
    
    //PERGUNTA 5
    while(pergunta5 != 2){
        while(vida == 0){
                alert("Suas vidas acabaram, Tente novamente!")
        }
        
        pergunta5 = Number(prompt("Após chegar à Alemanha, qual foi a principal área de foco para Muna Dahouk?\n\n1- Negócios e comércio\n2- Ajuda a refugiados\n3- Turismo e hospitalidade"))
        
            if(pergunta5 == 1){
                vida -= 1
                    alert("Resposta errada, tente novamente\nsua vida caiu de 3 para " +vida+ " tome mais cuidado da próxima vez!")
            }
        
        
            if(pergunta5 == 3){
                vida -= 1
                    alert("Resposta errada, tente novamente\nsua vida caiu de 3 para " +vida+ " tome mais cuidado da próxima vez!")
            }
        
        }
            
        
        
            if(pergunta5 == 2){
        
                vida += 1
                    alert("Resposta correta! Sua vida agora está em " +vida+ " continue assim!")
        
            }
        
        while(pergunta6 != 1){
        while(vida == 0){
            alert("Suas vidas acabaram, Tente novamente!")
        }
        
        //PERGUNTA 6
        pergunta6 = Number(prompt("Qual é a principal missão da ONG fundada por Muna Dahouk?\n\n1- Reassentar e integrar refugiados\n2- Apoiar empresas locais\n3- Promover eventos esportivos"))
        
        
            if(pergunta6 == 2){
        
            vida -= 1
                alert("Resposta errada, tente novamente\nsua vida caiu de 3 para " +vida+ " tome mais cuidado da próxima vez!")
        
        
            if(pergunta6 == 3){
        
            vida -= 1
                alert("Resposta errada, tente novamente\nsua vida caiu de 3 para " +vida+ " tome mais cuidado da próxima vez!")
        
        }
    }
        
            if(pergunta6 == 1){
        
            vida += 1
                alert("Resposta correta! Sua vida agora está em " +vida+ " continue assim!")
            

                alert("Parabéns você chegou nas olimpíadas, como você decidiu não ajudar a pessoa, você chegou em terceiro lugar!!!\n\ntente novamente para chegar em primeiro!")
    }
}
        }

    if(ourin4 == 1,2,3,4){

alert("Parabéns você comprou uma comida para a pessoa e ela ficou muito grata!")
alert("Parabéns, você conquistou \n\nGRATIDÃO | ESFORÇO")
    }

//PERGUNTA 5
while(pergunta5 != 2){
    while(vida == 0){
            alert("Suas vidas acabaram, Tente novamente!")
    }
    
    pergunta5 = Number(prompt("Após chegar à Alemanha, qual foi a principal área de foco para Muna Dahouk?\n\n1- Negócios e comércio\n2- Ajuda a refugiados\n3- Turismo e hospitalidade"))
    
        if(pergunta5 == 1){
            vida -= 1
                alert("Resposta errada, tente novamente\nsua vida caiu de 3 para " +vida+ " tome mais cuidado da próxima vez!")
        }
    
    
        if(pergunta5 == 3){
            vida -= 1
                alert("Resposta errada, tente novamente\nsua vida caiu de 3 para " +vida+ " tome mais cuidado da próxima vez!")
        }
    
    }
        
    
    
        if(pergunta5 == 2){
    
            vida += 1
                alert("Resposta correta! Sua vida agora está em " +vida+ " continue assim!")
    
        }
    
    while(pergunta6 != 1){
    while(vida == 0){
        alert("Suas vidas acabaram, Tente novamente!")
    }
    
    //PERGUNTA 6
    pergunta6 = Number(prompt("Qual é a principal missão da ONG fundada por Muna Dahouk?\n\n1- Reassentar e integrar refugiados\n2- Apoiar empresas locais\n3- Promover eventos esportivos"))
    
    
        if(pergunta6 == 2){
    
        vida -= 1
            alert("Resposta errada, tente novamente\nsua vida caiu de 3 para " +vida+ " tome mais cuidado da próxima vez!")
    
    
        if(pergunta6 == 3){
    
        vida -= 1
            alert("Resposta errada, tente novamente\nsua vida caiu de 3 para " +vida+ " tome mais cuidado da próxima vez!")
    
    }
}
    
        if(pergunta6 == 1){
    
        vida += 1
            alert("Resposta correta! Sua vida agora está em " +vida+ " continue assim!")
        
    
            alert("Parabéns você chegou nas olimpíadas, como você decidiu ajudar a pessoa, você chegou em primeiro lugar!!!")

}

}

        
    



